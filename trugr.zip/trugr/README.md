# requirements
/!\ You need to have the [Kalliope Core](https://github.com/kalliope-project/kalliope) installed before cloning this starter kit.

# kalliope starter config en

This is an out of the box working configuration for greek kalliope user
 
How to use
 ```bash
git clone https://github.com/nicksfikas/truaigr.git
cd truaigr
kalliope start
```
